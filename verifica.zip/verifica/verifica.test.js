const verifica = require('./verifica');
const calcola = require("./verifica");

//primo test semplice passato

/*test('test offusca ciao diventa CI40', () => {
    let prova = "ciao";
    expect(verifica(prova)).toBe("CI40");
  });*/

//test non passato inverte i primi due caratteri C dicenta 1 e I diventa C 
/*test('spazi in una stringa semplce con stessi spazi', () => {
    let prova = "c i a o   so no  it e";
    expect(verifica(prova)).toBe("C I 4 0   S0 N0  17 3");
  });*/

//da errore scambia il primo carattere con il secondo
test('secondo test per gli spazi', () => {
    let prova = "o t e";
    expect(verifica(prova)).toBe("0 7 3");
  });

//test per l'approssimazione
  test('test funzione calcola', () => {
    expect(calcola('sin(x) + 1', 1.5)).toBeCloseTo(1.9);
  });