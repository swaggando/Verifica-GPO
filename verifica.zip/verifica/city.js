// filename city.js

// Cerca nell'archivio fornito il nome indicato.
// Parametro archivio: lista di stringhe.
// Parametro nome: stringa da cercare.
// Restituisce true se il nome è presente, false altrimenti.
// Se anche solo uno dei parametri è null la funzione restituisce false.
var archivio = ["Milano" , "Bologna" ,  "Firenze", "Roma" , "Napoli" , "Palermo"];
function cerca(archivio, nome){
    for(let i = 0; i <6; i++){
        if(nome = archivio[i]){
            return true;
        }
    }

}

module.exports = {
    cerca
};
